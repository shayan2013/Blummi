import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class ARTIKEL {

	// VARIABLEN
	String artikelID, artikelName, farbe;
	float preis;
	Connection con;
	Statement st;
	ResultSet rs;
	String MSG = "**** ***";
	String url = "jdbc:mysql://localhost:3306/jy58";

	// KONSTRUKTOR
	public ARTIKEL() {

		// DRIVER
		try {
			Class.forName("org.gjt.mm.mysql.Driver");

		} catch (ClassNotFoundException e) {
			MSG = e.getMessage();
		}

		// CONNECTION
		try {
			con = DriverManager.getConnection(url, "jy58", "FPDU");
			st = con.createStatement();

			// ARTIKEL-TABLE KREIEREN & INSERT
			st.executeUpdate("create table if not exists ARTIKEL (artikelID varchar(10),"
					+ " artikelName varchar(50),"
					+ " farbe varchar(20),"
					+ " preis float(6,2), "
					+ " primary key(artikelID)) engine= INNODB;");

		} catch (Exception e) {
			// Im Fall dass es ein Problem mit dem Kreieren der Tabelle
			// WARENKORB auftaucht
			MSG = e.getLocalizedMessage();
		}

	}// KONSTRUKTOR ENDET
	
	
	// METHODE: insert()
	// Sie erwartet Parameter die in die Tabelle ARTIKEL eigefuegt werden.
	public void insert(String artikelID, String artikelName, String farbe, float preis) {
			try {
				int i = st.executeUpdate("insert into ARTIKEL values ('"
						+ artikelID + "','" + artikelName  + "','" + farbe + "','" + preis
						+ "')");
				if (i > 0) {
					MSG = "artikel in die DB hinzugefuegt";
				} else {
					MSG = "Fehler!";
				}
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
	}

	// METHODE: delete
	// loescht ein Artikel aus der DB Warenkorb
	public void delete(String id) {
		try {
			int i = st.executeUpdate("delete from ARTIKEL where artikelID ='"
					+ id + "'");

			if (i > 0) {
				MSG = "Artikel geloescht";
			} else {
				MSG = "Fehler!";

			}
		} catch (Exception e) {
			MSG=(e.getMessage());
		}
	}

	// METHODE: getMSG()
	// RETURN: Status-Return ueber Fehler usw...
	public String getMSG() {
		return MSG;
	}

}
