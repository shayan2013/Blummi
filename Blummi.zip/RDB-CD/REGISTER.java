import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;


public class REGISTER {
	
	String NAME, VORNAME, STRASSE, PLZ, ORT, EMAIL, TEL, PWD;
	String sname, snr;
    Connection con;
    Statement st;
    ResultSet rs;
    String MSG = "****   ****";
    String url= "jdbc:mysql://localhost:3306/jy58";
    
     public REGISTER (String NAME,String VORNAME,String STRASSE,String PLZ,String ORT,String EMAIL,String TEL,String PWD)
     {
    	 this.NAME= NAME;
    	 this.VORNAME=VORNAME;
    	 this.STRASSE=STRASSE;
    	 this.PLZ=PLZ;
    	 this.ORT=ORT;
    	 this.EMAIL=EMAIL;
    	 this.TEL=TEL;
    	 this.PWD=PWD;
    	 
    	 //DRIVER
    	 try{
    		 Class.forName("org.gjt.mm.mysql.Driver");
    		 
    	 }
    	 catch (ClassNotFoundException e){
    		 MSG = e.getMessage();
    		 
    	 }
    	 
    	 //CONNECTION
    	 try{
    		 con = DriverManager.getConnection(url,"jy58","FPDU");
    		 st = con.createStatement();  
    		 
    		 
    		//KUNDEN-TABLE KREIEREN & INSERT 
    		st.executeUpdate("create table if not exists KUNDEN (nachName varchar(30) NOT NULL,"
    				+ "vorName varchar (20) NOT NULL,"
    				+ "strasse varchar(50) NOT NULL,"
    				+ "plz varchar(5) NOT NULL,"
    				+ "ort varchar(20) NOT NULL,"
    				+ "telefon varchar(20) NOT NULL,"
    				+ "email varchar(50) NOT NULL,"
    				+ "pwd varchar(10) NOT NULL,"
    				+ "primary key(email))"
    				+ "engine=INNODB;");
    		
			//ABFRAGEN: KEINE EINTRAEGE WEN DIE "FELDER" NICHT AUSGEFUEHLLT WORDEN SIND.
    		if (NAME =="" || VORNAME =="" || EMAIL =="" || TEL =="" || STRASSE =="" || PLZ =="" || ORT =="" || PWD ==""){
			 MSG="			BITTE JEDES FELD AUSFUELLEN! ";
}
			//ABFRAGEN: KEINE null EINTRAEGE.
			else if (NAME == null || VORNAME==null || STRASSE==null || PLZ==null || ORT==null || TEL ==null || EMAIL == null|| PWD==null){
						MSG="";
			}
			//NUR DANN IN DIE TABELLE REIN WENN DIE "FELDER"" MIT WERTEN "GEFUTTERT" SIND 
    		else {
					int i = st.executeUpdate("insert into KUNDEN(nachName, vorName, email, telefon, strasse, plz, ort, pwd ) values ('" + NAME + "','" + VORNAME + "','" + EMAIL + "','" + TEL + "','" + STRASSE + "','"+ PLZ + "','"+ ORT +"','"+PWD +"')");
					if (i > 0) {
		    	        //session.setAttribute("userid", user);
		    	    	//response.sendRedirect("welcome.jsp");
		    	       MSG = "Registration ERFOLGREICH!!!  BITTE ANMELDEN";
		    	    } else {
		    	       // response.sendRedirect("index.jsp");
		    	        MSG = "REGISTRATION FAILED!";

		    	    }

			}
    	 
    	 	st.close();
		   con.close();
    	 
    	 }
    	 catch(Exception e){
    		 MSG="			FAILD 2 CONNECT .... :(";
    		 System.out.println(e.getMessage());
    		 
    	 }
    	 

}

     public String getMSG(){
	return MSG;
}

}
