import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class WARENKORB {
    
	// VARIABLEN
	String artikelID, email;
	int stueckZahl;
	Connection con;
	Statement st;
	ResultSet rs;
	String MSG = "**** ***";
	String url = "jdbc:mysql://localhost:3306/jy58";
    
	// KONSTRUKTOR
	public WARENKORB() {
        
		// DRIVER
		try {
			Class.forName("org.gjt.mm.mysql.Driver");
            
		} catch (ClassNotFoundException e) {
			MSG = e.getMessage();
		}
        
		// CONNECTION
		try {
			con = DriverManager.getConnection(url, "jy58", "FPDU");
			st = con.createStatement();
            
			// WARENKORB-TABLE KREIEREN & INSERT
			st.executeUpdate("create table if not exists WARENKORB (rechnungNR int(4) NOT NULL AUTO_INCREMENT,"
                             + " artikelID varchar(10),"
                             + " stueckZahl int (4),"
                             + " email varchar(50),"
                             + " primary key(rechnungNR, artikelID, email),"
                             + " constraint foreign key (artikelID) "
                             + "references ARTIKEL(artikelID) "
                             + "on update cascade "
                             + "on delete cascade,"
                             + " constraint foreign key (email)"
                             + " references KUNDEN(email)"
                             + " on update cascade"
                             + " on delete cascade )" + "engine= INNODB;");
            
		} catch (Exception e) {
			// Im Fall dass es ein Problem mit dem Kreieren der Tabelle
			// WARENKORB auftaucht
			MSG = e.getLocalizedMessage();
		}
        
	}// KONSTRUKTOR ENDET
    
	// METHODE: schreiben()
	// Sie erwartet 4 Parameter die in die Tabelle WARENKORB eigefuegt werden.
	public void schreiben(String artikelID, String email, int stueckZahl) {
        
		try {
			int i = st
            .executeUpdate("insert into WARENKORB (artikelID,stueckZahl,email ) values ('"
                           + artikelID
                           + "','"
                           + stueckZahl
                           + "','"
                           + email
                           + "')");
            
			if (i > 0) {
				MSG = "in warenkorb hinzugefuegt";
			} else {
				MSG = "FAILED!";
                
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
    
	// METHODE: delete
	// loescht ein Artikel aus der DB Warenkorb
	public void delete(String id, String email) {
		try {
			int i = st
            .executeUpdate("delete from WARENKORB where WARENKORB.artikelID ='"
                           + id
                           + "' AND WARENKORB.email = '"
                           + email
                           + "'");
            
			if (i > 0) {
				MSG = "Artikel geloescht";
			} else {
				MSG = "FAILED!";
                
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
    
	// METHODE: getMSG()
	// RETURN: Status-Return ueber Fehler usw...
	public String getMSG() {
		return MSG;
	}
    
}
